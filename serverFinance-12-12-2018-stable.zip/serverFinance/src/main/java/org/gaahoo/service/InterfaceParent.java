package org.gaahoo.service;

public interface InterfaceParent {

	
	public Class<?> count();
	public void search();
	public void all();
	public void save();
	public void delete();
}
